Wellcome, {{ $name }}
Please active your account : {{ url('activation/users', $link)}}
