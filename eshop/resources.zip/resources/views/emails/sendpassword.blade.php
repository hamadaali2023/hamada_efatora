<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <h2>Forget Password Email</h2>
    <p>{{ $new_password }}</p>
  </body>
</html>