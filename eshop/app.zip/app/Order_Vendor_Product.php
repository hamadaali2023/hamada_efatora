<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_Vendor_Product extends Model
{
    protected $table = 'order_vendor_product';
}
