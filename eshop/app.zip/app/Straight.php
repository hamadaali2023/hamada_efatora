<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Straight extends Model
{
    protected $table = 'lives';
}
